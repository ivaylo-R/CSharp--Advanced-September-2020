﻿using System;
using System.IO.Compression;

namespace _06._Zip_and_Extract
{
    class Program
    {
        static void Main(string[] args)
        {
            ZipFile.CreateFromDirectory(@"C:\Users\Ana-Maria\source\repos\04. StreamsFilesAndDirectories-Ex\06. Zip and Extract", @"C:\Users\Ana-Maria\source\repos\04. StreamsFilesAndDirectories-Ex\newFile5.zip");
        }
    }
}
